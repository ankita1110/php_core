<?php
include('con.php');
include('storep_insert.php');
$id=$_REQUEST['up'];

$sq="select name,city from std where id=".$id;
$sel=mysqli_query($conn,$sq);
$se=mysqli_fetch_array($sel);
$n=$_REQUEST['fname'];
$c=$_REQUEST['city'];
//echo $se['name']."<br>";
//echo $se['city'];

?>



<html>
<head></head>
<body>
<form method="post" action="#">
full name
    <input type="text" name="fname" value="<?php echo $se['name'];?>">
    <br>



 city
        <input type="text" name="city" value="<?php echo $se['city'];?>">
        <br>

   <input type="submit" name="submit" value="submit">
      <input type="submit" name="update" value="update">


</form>



<?php

 include('disply.php');
?>


</body>
</html>
<?php
     if(isset($_REQUEST['update']))
     {
        $s="update std set name='$n',city='$c' where id=".$id;
        echo $s;
        $es=mysqli_query($conn,$s);
        header('location:ankita.php');
     }
     if(isset($_REQUEST['submit']))
     {
         $result=insertstd($n,$c,"0");
      		if($result==1)
      		{
      			header('location:ankita.php');
      		}
        //include('insert.php');
     }


?>

