<?php
include('con.php');
?>
<html>
<head>

    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
    <script src="//code.jquery.com/jquery-1.12.4.js"></script>
    <script src="//cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            // Setup - add a text input to each footer cell
            $('#example tfoot th').each( function () {
                var title = $(this).text();
                $(this).html( '<input type="text" placeholder="Search '+title+'" />' );
            } );

            // DataTable
            var table = $('#example').DataTable();

            // Apply the search
            table.columns().every( function () {
                var that = this;

                $( 'input', this.footer() ).on( 'keyup change', function () {
                    if ( that.search() !== this.value ) {
                        that
                            .search( this.value )
                            .draw();
                    }
                } );
            } );
        } );
    </script>
</head>
<body>
<table id="example" class="display" cellspacing="0" width="100%">
    <thead>
    <tr>
        <th>Name</th>
        <th>City</th>
        <th>Delete</th>
        <th>Update</th>
    </tr>
    <tfoot>
    <tr>
        <th>Name</th>
        <th>City</th>
        <th>Delete</th>
        <th>Update</th>
    </tr>
    </tfoot>
    </thead>


    <tbody>

    <?php
    $select="select * from std where flag=0";
    $sel=mysqli_query($conn,$select);
    if(mysqli_num_rows($sel)>0)
    {
        while($se=mysqli_fetch_array($sel))
        {
            ?>
            <tr>
                <td><?php echo $se['name'];?></td>
                <td><?php echo $se['city'];?></td>

                <td><a href="delete.php?del=<?php echo $se['id'];?>">Delete</td>
                <td><a href="ankita.php?up=<?php echo $se['id'];?>">Update</td>
            </tr>

            <?php
        }
    }
    else
    {
        echo "not data found";
    }
    ?>
    </tbody>
</table>
</body>




</html>
