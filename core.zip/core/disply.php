<?php
include('con.php');
?>
<html>
<head>
    <script src="datatable/js/jquery-2.2.0.js"></script>
    <link rel="stylesheet" href="datatable/js/jquery-ui-1.11.4/jquery-ui.css"/>

    <!--<script src="datatable/js/jquery-1.12.0.min.js"></script>-->
    <!--<script src="datatable/js/jquery-ui-1.11.4/jquery-ui.js"></script>-->

    <link rel="stylesheet" href="datatable/css/jquery.dataTables.min.css"/>
    <script type="text/javascript" src="datatable/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#example").DataTable();
        } );
    </script>


</head>
<body>
<table id="example" class="display" cellspacing="0" width="100%">
    <thead>
    <tr>
        <th>Name</th>
        <th>City</th>
        <th>Delete</th>
        <th>Update</th>
    </tr>
    </thead>


    <tbody>

    <?php
    $select="select * from std where flag=0";
    $sel=mysqli_query($conn,$select);
    if(mysqli_num_rows($sel)>0)
    {
        while($se=mysqli_fetch_array($sel))
        {
            ?>
            <tr>
                <td><?php echo $se['name'];?></td>
                <td><?php echo $se['city'];?></td>

                <td><a href="delete.php?del=<?php echo $se['id'];?>">Delete</td>
                <td><a href="ankita.php?up=<?php echo $se['id'];?>">Update</td>
            </tr>

            <?php
        }
    }
    else
    {
        echo "not data found";
    }
   ?>
    </tbody>
</table>
</body>



</html>
