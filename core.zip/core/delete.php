<?php
include('con.php');
$id=$_REQUEST['del'];
echo ($id);

$del = "UPDATE std SET flag = 1 WHERE id=".$id;

//$del="delete from std where id=".$id;
//echo ($del);

$qu=mysqli_query($conn,$del);
if($qu>0)
{
    header('location:ankita.php');
}
else
{
    echo "not delete";
}
//die();
