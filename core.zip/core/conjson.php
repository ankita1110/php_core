<html>
<head>
    <script src="https://code.jquery.com/jquery-1.12.4.min.js">
    </script>
</head>
<body>
        <?php
$json=file_get_contents("http://192.168.200.29:4000/show");
echo $json;
$data =  json_decode($json);
print_r($data);
?>
</body>

</html>




