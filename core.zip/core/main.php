/update_operation
$(".updatedata").click(function() {
var _id = $(this).attr("id");
alert(_id);
$req="http://localhost:4300/customers/fetch/"+_id;
$.ajax({
type: 'GET',
url: $req,
success: function (d) {
console.log(d);
//var d=JSON.stringify(data);
//console.log(JSON.stringify(data));
$('#name').val(d[0].name);
$('#password').val(d[0].password);
$('#address').val(d[0].address);
$('#email').val(d[0].email);
$('#phone').val(d[0].phone);
$('#submit').hide();
$('#update').show();
$("#update").click(function(){
alert("click update")
var _id =d[0].id;
var name = $('#name').val();
var password = $('#password').val();
var address = $('#address').val();
var email = $('#email').val();
var phone = $('#phone').val();
alert(_id+" "+name+" "+password+" "+address+" "+email+" "+phone);
$.ajax({
type: 'POST',
url: "http://localhost:4300/customers/edit/"+_id,
data: {name: name, password: password, address: address, email: email, phone: phone},
success: function (data) {
//    alert(response.status);
console.log(data);
//display data
$('#submit').show();
$('#update').hide();
$('#name').val(" ");
$('#password').val(" ");
$('#address').val(" ");
$('#email').val(" ");
$('#phone').val(" ");
display();


},
error: function () {
alert("error");

console.log("error");
}
});
});
//display data
display();

},
error: function () {
alert("error");

console.log("error");
}
});
//edit customer route , get n post
app.get('/customers/fetch/:id', (req,res)=>{
var id = req.params.id;

console.log('select update data '+id);
connection.query('SELECT * FROM customer WHERE id ='+id,function(err,rows)
{

if(err)
console.log("Error Selecting : %s ",err );
res.send(rows);
//console.log(rows);
// res.send("sucecss",data:rows});

});


});
app.post('/customers/edit/:id',(req,res)=>{

var input = JSON.parse(JSON.stringify(req.body));
var id = req.params.id;


console.log('update data');
var data = {

name    : input.name,
address : input.address,
email   : input.email,
phone   : input.phone

};

connection.query("UPDATE customer set ? WHERE id = ? ",[data,id], function(err, rows)
{

if (err)
console.log("Error Updating  ",err );

res.send('hi');

});

});