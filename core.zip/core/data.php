<?php
include('con.php');
include ('table.php');
?>
<html>
<head>

</head>
<body>
<table border="1" width="60%">
    <thead>
    <tr>
        <th>Name</th>
        <th>City</th>
        <th>Delete</th>
        <th>Update</th>
    </tr>
    </thead>


    <tbody>

    <?php
    $q = $_REQUEST['name'];
    $select="select * from std where name='".$q."'";;
    $sel=mysqli_query($conn,$select);
    if(mysqli_num_rows($sel)>0)
    {
        while($se=mysqli_fetch_array($sel))
        {
            ?>
            <tr>
                <td><?php echo $se['name'];?></td>
                <td><?php echo $se['city'];?></td>

                <td><a href="delete.php?del=<?php echo $se['id'];?>">Delete</td>
                <td><a href="ankita.php?up=<?php echo $se['id'];?>">Update</td>
            </tr>

            <?php
        }
    }
    else
    {
        echo "not data found";
    }
    ?>
    </tbody>
</table>
</body>



</html>
