<?php
    $conn=mysqli_connect("localhost","root","LANETTEAM1","demo");
    if(!$conn)
    {
        die("not connected".mysqli_connect_error());
    }




?>
